Air Quality Prediction using ML

1) Browse through *Air Quality Prediction Code* folder.

2) And then move to *Air_Quality* folder.

3) Open Command Prompt and change the directory to the specified location mentioned above.

4) After that type python "AQ_app.py" command in the Command Prompt.

5) After few seconds type "streamlit run AQ_app.py" command in the Command Prompt which indeed enables a 
local host environment for the code.

6) Then enter the specified values for the Air Quality Prediction and hit 'Predict' button below.

7) Finally the predicted Air Quality Index (AQI) has been displayed.